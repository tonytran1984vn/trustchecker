import { serverApi } from "@/lib/server/api";

export const dynamic = 'force-dynamic';
export const revalidate = 0;

async function fetchData() {
  try {
    return await serverApi.get('/api/executive/reports');
  } catch (error) {
    return null;
  }
}

export default async function Page() {
  const data = await fetchData();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Reports</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Regulatory filings and aggregated organizational reporting.</p>
        </div>
      </div>

      {!data ? (
        <div className="bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 p-6 rounded-xl border border-red-200 dark:border-red-500/20 w-full text-center">
          <h2 className="font-semibold text-lg mb-2">Data Load Error</h2>
          <p className="text-sm">Cannot connect to the backend engine to retrieve configuration.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-100">
          <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
             <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4">Module Initialized</h3>
             <pre className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg text-xs overflow-auto text-emerald-600 dark:text-emerald-400 border border-slate-100 dark:border-slate-800">
                 {JSON.stringify(data, null, 2)}
             </pre>
          </div>
          
          <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col justify-center items-center text-center">
             <h3 className="font-medium text-slate-700 dark:text-slate-300">Awaiting Visualization Render</h3>
             <p className="text-sm text-slate-500 mt-2">Data is flowing securely. The high-fidelity Chart.js/Recharts layer for this module is scheduled in the next CI deployment.</p>
          </div>
        </div>
      )}
    </div>
  );
}
